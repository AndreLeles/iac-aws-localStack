## Installation

[link documentação site oficial](https://docs.localstack.cloud/getting-started/installation/)

You can download the respective binary for your architecture directly:

For x86-64:
```sh
curl -Lo localstack-cli-3.1.0-linux-amd64-onefile.tar.gz \
    https://github.com/localstack/localstack-cli/releases/download/v3.1.0/localstack-cli-3.1.0-linux-amd64-onefile.tar.gz
```


Then extract the LocalStack CLI from the terminal:

```sh
sudo tar xvzf localstack-cli-3.1.0-linux-*-onefile.tar.gz -C /usr/local/bin
```


To verify that the LocalStack CLI was installed correctly, you can check the version in your terminal:

```sh
localstack --version
```

## instalation AWS Command Line Interface (CLI) - use localstack

[link documentação site oficial](https://docs.localstack.cloud/user-guide/integrations/aws-cli/#localstack-aws-cli-awslocal)



```sh
pip install awscli-local
```


## Starting LocalStack

You can start LocalStack with Docker Compose by configuring a docker-compose.yml file. Currently, docker-compose version 1.9.0+ is supported.

```sh
version: "3.8"
services:
  localstack:
    container_name: localstack
    image: localstack/localstack
    ports:
      - '127.0.0.1:4566:4566'
      - '127.0.0.1:4571:4571'
    environment:
      # LocalStack configuration: https://docs.localstack.cloud/references/configuration/
      - LOCALSTACK_AUTH_TOKEN="ls-FosIJIBO-luBa-WUpe-9377-8829bUlo181f"
      - DEBUG=1
      - SERVICES=logs,cloudformation,iam,s3,lambda,apigateway
      - DATA_DIR=/tmp/localstack/data
      - LAMBDA_EXECUTOR=docker
      - LAMBDA_REMOTE_DOCKER=false
      - DOCKER_HOST=unix:///var/run/docker.sock
      - AWS_ACCESS_KEY_ID=test
      - AWS_SECRET_ACCESS_KEY=test
    volumes:
      - "${LOCALSTACK_VOLUME_DIR:-./volume}:/var/lib/localstack"
      - "/var/run/docker.sock:/var/run/docker.sock"
```

Start the container by running the following command:

```sh
docker-compose up -d
```

## starting LocalStack in Docker mod
Need instalation docker local

```sh
localstack start
```
The simplest method to verify if LocalStack is active is by querying the health endpoint for a list of running services:

```sh
curl http://localhost:4566/_localstack/info | jq
```

The following output would be retrieved:

```sh
{
  "version": "3.1.1.dev:fee871a1",
  "edition": "community",
  "is_license_activated": false,
  "session_id": "03970e19-1c4f-4b4b-b5c0-d1f33a34156f",
  "machine_id": "dkr_b4f5329772e0",
  "system": "linux",
  "is_docker": true,
  "server_time_utc": "2024-02-06T00:47:53",
  "uptime": 42
}

```

## Comando para verificar serviço dosponivel para usar local

```sh
localstack status services
```

##


```sh
┏━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━┓
┃ Service                  ┃ Status      ┃
┡━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━┩
│ acm                      │ ✔ available │
│ apigateway               │ ✔ available │
│ cloudformation           │ ✔ available │
│ cloudwatch               │ ✔ available │
│ config                   │ ✔ available │
│ dynamodb                 │ ✔ available │
│ dynamodbstreams          │ ✔ available │
│ ec2                      │ ✔ available │
│ es                       │ ✔ available │
│ events                   │ ✔ available │
│ firehose                 │ ✔ available │
│ iam                      │ ✔ available │
│ kinesis                  │ ✔ available │
│ kms                      │ ✔ available │
│ lambda                   │ ✔ available │
│ logs                     │ ✔ available │
│ opensearch               │ ✔ available │
│ redshift                 │ ✔ available │
│ resource-groups          │ ✔ available │
│ resourcegroupstaggingapi │ ✔ available │
│ route53                  │ ✔ available │
│ route53resolver          │ ✔ available │
│ s3                       │ ✔ available │
│ s3control                │ ✔ available │
│ scheduler                │ ✔ available │
│ secretsmanager           │ ✔ available │
│ ses                      │ ✔ available │
│ sns                      │ ✔ available │
│ sqs                      │ ✔ available │
│ ssm                      │ ✔ available │
│ stepfunctions            │ ✔ available │
│ sts                      │ ✔ available │
│ support                  │ ✔ available │
│ swf                      │ ✔ available │
│ transcribe               │ ✔ available │
└──────────────────────────┴─────────────┘
```

## How to use the JavaScript AWS SDK with LocalStack.

[link documentação site oficial](https://docs.localstack.cloud/user-guide/integrations/sdks/javascript/)


## Troubleshooting

You can now avail logging output and error reporting using LocalStack logs. To access the logs, run the following command:

```sh
localstack logs
```
